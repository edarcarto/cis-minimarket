<!-- First Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('first_name', 'First Name:'); ?>

    <?php echo Form::text('first_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Last Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('last_name', 'Last Name:'); ?>

    <?php echo Form::text('last_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Document Type Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('document_type', 'Document Type:'); ?>

    <?php echo Form::select('document_type', ['1' => 'CE', '2' => 'DNI', '3' => 'RUC'], null, ['class' => 'form-control']); ?>

</div>

<!-- Document Number Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('document_number', 'Document Number:'); ?>

    <?php echo Form::text('document_number', null, ['class' => 'form-control']); ?>

</div>

<!-- Phone Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('phone', 'Phone:'); ?>

    <?php echo Form::text('phone', null, ['class' => 'form-control']); ?>

</div>

<!-- Departament Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('departament', 'Departament:'); ?>

    <?php echo Form::select('departament', [], null, ['class' => 'form-control']); ?>

</div>

<!-- Province Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('province', 'Province:'); ?>

    <?php echo Form::select('province', [], null, ['class' => 'form-control']); ?>

</div>

<!-- District Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('district', 'District:'); ?>

    <?php echo Form::select('district', [], null, ['class' => 'form-control']); ?>

</div>

<!-- Address Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('address', 'Address:'); ?>

    <?php echo Form::text('address', null, ['class' => 'form-control']); ?>

</div>

<!-- Number Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('number', 'Number:'); ?>

    <?php echo Form::number('number', null, ['class' => 'form-control']); ?>

</div>

<!-- Legal Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('legal', 'Legal:'); ?>

    <label class="checkbox-inline">
        <?php echo Form::hidden('legal', 0); ?>

        <?php echo Form::checkbox('legal', '1', null); ?>

    </label>
</div>


<!-- Tyc Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('tyc', 'Tyc:'); ?>

    <label class="checkbox-inline">
        <?php echo Form::hidden('tyc', 0); ?>

        <?php echo Form::checkbox('tyc', '1', null); ?>

    </label>
</div>


<!-- Active Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('active', 'Active:'); ?>

    <label class="checkbox-inline">
        <?php echo Form::hidden('active', 0); ?>

        <?php echo Form::checkbox('active', '1', null); ?>

    </label>
</div>


<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/customers/fields.blade.php ENDPATH**/ ?>