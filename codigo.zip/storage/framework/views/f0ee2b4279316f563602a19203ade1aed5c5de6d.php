<!-- Company Name Field -->
<div class="form-group">
    <?php echo Form::label('company_name', 'Nombre de Compañia:'); ?>

    <p><?php echo e($supplier->company_name); ?></p>
</div>

<!-- Contact Name Field -->
<div class="form-group">
    <?php echo Form::label('contact_name', 'Nombre del Contacto:'); ?>

    <p><?php echo e($supplier->contact_name); ?></p>
</div>

<!-- Contact Title Field -->
<div class="form-group">
    <?php echo Form::label('contact_title', 'Puesto:'); ?>

    <p><?php echo e($supplier->contact_title); ?></p>
</div>

<!-- Address Field -->
<div class="form-group">
    <?php echo Form::label('address', 'Dirección:'); ?>

    <p><?php echo e($supplier->address); ?></p>
</div>

<!-- City Field -->
<div class="form-group">
    <?php echo Form::label('city', 'Ciudad:'); ?>

    <p><?php echo e($supplier->city); ?></p>
</div>

<!-- Region Field -->
<div class="form-group">
    <?php echo Form::label('region', 'Región:'); ?>

    <p><?php echo e($supplier->region); ?></p>
</div>

<!-- Postal Code Field -->
<div class="form-group">
    <?php echo Form::label('postal_code', 'Codigo Postal:'); ?>

    <p><?php echo e($supplier->postal_code); ?></p>
</div>

<!-- Country Field -->
<div class="form-group">
    <?php echo Form::label('country', 'Pais:'); ?>

    <p><?php echo e($supplier->country); ?></p>
</div>

<!-- Phone Field -->
<div class="form-group">
    <?php echo Form::label('phone', 'Teléfono:'); ?>

    <p><?php echo e($supplier->phone); ?></p>
</div>

<!-- Fax Field -->
<div class="form-group">
    <?php echo Form::label('fax', 'Fax:'); ?>

    <p><?php echo e($supplier->fax); ?></p>
</div>

<!-- Homepage Field -->
<div class="form-group">
    <?php echo Form::label('homepage', 'Pagina Web:'); ?>

    <p><?php echo e($supplier->homepage); ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($supplier->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($supplier->updated_at); ?></p>
</div>

<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/suppliers/show_fields.blade.php ENDPATH**/ ?>