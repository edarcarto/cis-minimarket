<!-- Customer Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('customer_id', 'Customer Id:'); ?>

    <?php echo Form::select('customer_id', $customerItems, null, ['class' => 'form-control']); ?>

</div>

<!-- Order Date Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('order_date', 'Order Date:'); ?>

    <?php echo Form::text('order_date', null, ['class' => 'form-control']); ?>

</div>

<!-- Required Date Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('required_date', 'Required Date:'); ?>

    <?php echo Form::text('required_date', null, ['class' => 'form-control']); ?>

</div>

<!-- Shipped Date Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('shipped_date', 'Shipped Date:'); ?>

    <?php echo Form::text('shipped_date', null, ['class' => 'form-control']); ?>

</div>

<!-- Ship Via Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('ship_via', 'Ship Via:'); ?>

    <?php echo Form::text('ship_via', null, ['class' => 'form-control']); ?>

</div>

<!-- Freight Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('freight', 'Freight:'); ?>

    <?php echo Form::text('freight', null, ['class' => 'form-control']); ?>

</div>

<!-- Ship Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('ship_name', 'Ship Name:'); ?>

    <?php echo Form::text('ship_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Ship Address Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('ship_address', 'Ship Address:'); ?>

    <?php echo Form::text('ship_address', null, ['class' => 'form-control']); ?>

</div>

<!-- Ship City Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('ship_city', 'Ship City:'); ?>

    <?php echo Form::text('ship_city', null, ['class' => 'form-control']); ?>

</div>

<!-- Ship Region Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('ship_region', 'Ship Region:'); ?>

    <?php echo Form::text('ship_region', null, ['class' => 'form-control']); ?>

</div>

<!-- Ship Postal Code Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('ship_postal_code', 'Ship Postal Code:'); ?>

    <?php echo Form::text('ship_postal_code', null, ['class' => 'form-control']); ?>

</div>

<!-- Ship Country Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('ship_country', 'Ship Country:'); ?>

    <?php echo Form::text('ship_country', null, ['class' => 'form-control']); ?>

</div>

<!-- Active Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('active', 'Active:'); ?>

    <label class="checkbox-inline">
        <?php echo Form::hidden('active', 0); ?>

        <?php echo Form::checkbox('active', '1', null); ?>

    </label>
</div>


<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/orders/fields.blade.php ENDPATH**/ ?>