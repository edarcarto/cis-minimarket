<div class="table-responsive">
    <table class="table" id="suppliers-table">
        <thead>
            <tr>
                <th>Nombre de Compañia</th>
                <th>Nombre del Contacto</th>
                <th>Puesto</th>
                <th>Dirección</th>
                <th>Ciudad</th>
                <th>Región</th>
                <th>Código Postal</th>
                <th>País</th>
                <th>Teléfono</th>
                <th>Fax</th>
                <th>Pagina Web</th>
                <th colspan="3">Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($supplier->company_name); ?></td>
            <td><?php echo e($supplier->contact_name); ?></td>
            <td><?php echo e($supplier->contact_title); ?></td>
            <td><?php echo e($supplier->address); ?></td>
            <td><?php echo e($supplier->city); ?></td>
            <td><?php echo e($supplier->region); ?></td>
            <td><?php echo e($supplier->postal_code); ?></td>
            <td><?php echo e($supplier->country); ?></td>
            <td><?php echo e($supplier->phone); ?></td>
            <td><?php echo e($supplier->fax); ?></td>
            <td><?php echo e($supplier->homepage); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['suppliers.destroy', $supplier->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('suppliers.show', [$supplier->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('suppliers.edit', [$supplier->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/suppliers/table.blade.php ENDPATH**/ ?>