<footer class="text-muted">
  <div class="container">
    <p class="float-right">
      <a href="#">Ir Arriba</a>
    </p>
    <p>Grupo Nro 1 UTP!</p>
    <p>2020 &copy; .</p>
  </div>
</footer><?php /**PATH /home/vagrant/Code/miniMarket/resources/views/parts/footer.blade.php ENDPATH**/ ?>