<!-- Trade Name Field -->
<div class="form-group">
    <?php echo Form::label('trade_name', 'Nombre de la Marca:'); ?>

    <p><?php echo e($trademark->trade_name); ?></p>
</div>

<!-- Active Field -->
<div class="form-group">
    <?php echo Form::label('active', 'Activo:'); ?>

    <p><?php echo e($trademark->active); ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($trademark->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($trademark->updated_at); ?></p>
</div>

<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/trademarks/show_fields.blade.php ENDPATH**/ ?>