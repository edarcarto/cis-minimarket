<div class="table-responsive">
    <table class="table" id="customers-table">
        <thead>
            <tr>
                <th>First Name</th>
        <th>Last Name</th>
        <th>Document Type</th>
        <th>Document Number</th>
        <th>Phone</th>
        <th>Departament</th>
        <th>Province</th>
        <th>District</th>
        <th>Address</th>
        <th>Number</th>
        <th>Legal</th>
        <th>Tyc</th>
        <th>Active</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($customer->first_name); ?></td>
            <td><?php echo e($customer->last_name); ?></td>
            <td><?php echo e($customer->document_type); ?></td>
            <td><?php echo e($customer->document_number); ?></td>
            <td><?php echo e($customer->phone); ?></td>
            <td><?php echo e($customer->departament); ?></td>
            <td><?php echo e($customer->province); ?></td>
            <td><?php echo e($customer->district); ?></td>
            <td><?php echo e($customer->address); ?></td>
            <td><?php echo e($customer->number); ?></td>
            <td><?php echo e($customer->legal); ?></td>
            <td><?php echo e($customer->tyc); ?></td>
            <td><?php echo e($customer->active); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['customers.destroy', $customer->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('customers.show', [$customer->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('customers.edit', [$customer->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/customers/table.blade.php ENDPATH**/ ?>