<!-- Trade Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('trade_name', 'Nombre de la Marca:'); ?>

    <?php echo Form::text('trade_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Active Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('active', 'Activo:'); ?>

    <label class="checkbox-inline">
        <?php echo Form::hidden('active', 0); ?>

        <?php echo Form::checkbox('active', '1', null); ?>

    </label>
</div>


<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('trademarks.index')); ?>" class="btn btn-default">Cancelar</a>
</div>
<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/trademarks/fields.blade.php ENDPATH**/ ?>