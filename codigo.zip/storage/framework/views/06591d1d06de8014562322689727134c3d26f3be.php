<div class="table-responsive">
    <table class="table" id="orders-table">
        <thead>
            <tr>
                <th>Customer Id</th>
        <th>Order Date</th>
        <th>Required Date</th>
        <th>Shipped Date</th>
        <th>Ship Via</th>
        <th>Freight</th>
        <th>Ship Name</th>
        <th>Ship Address</th>
        <th>Ship City</th>
        <th>Ship Region</th>
        <th>Ship Postal Code</th>
        <th>Ship Country</th>
        <th>Active</th>
                <th colspan="3">Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($order->customer_id); ?></td>
            <td><?php echo e($order->order_date); ?></td>
            <td><?php echo e($order->required_date); ?></td>
            <td><?php echo e($order->shipped_date); ?></td>
            <td><?php echo e($order->ship_via); ?></td>
            <td><?php echo e($order->freight); ?></td>
            <td><?php echo e($order->ship_name); ?></td>
            <td><?php echo e($order->ship_address); ?></td>
            <td><?php echo e($order->ship_city); ?></td>
            <td><?php echo e($order->ship_region); ?></td>
            <td><?php echo e($order->ship_postal_code); ?></td>
            <td><?php echo e($order->ship_country); ?></td>
            <td><?php echo e($order->active); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['orders.destroy', $order->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('orders.show', [$order->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('orders.edit', [$order->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/orders/table.blade.php ENDPATH**/ ?>