<!-- Customer Id Field -->
<div class="form-group">
    <?php echo Form::label('customer_id', 'Customer Id:'); ?>

    <p><?php echo e($order->customer_id); ?></p>
</div>

<!-- Order Date Field -->
<div class="form-group">
    <?php echo Form::label('order_date', 'Order Date:'); ?>

    <p><?php echo e($order->order_date); ?></p>
</div>

<!-- Required Date Field -->
<div class="form-group">
    <?php echo Form::label('required_date', 'Required Date:'); ?>

    <p><?php echo e($order->required_date); ?></p>
</div>

<!-- Shipped Date Field -->
<div class="form-group">
    <?php echo Form::label('shipped_date', 'Shipped Date:'); ?>

    <p><?php echo e($order->shipped_date); ?></p>
</div>

<!-- Ship Via Field -->
<div class="form-group">
    <?php echo Form::label('ship_via', 'Ship Via:'); ?>

    <p><?php echo e($order->ship_via); ?></p>
</div>

<!-- Freight Field -->
<div class="form-group">
    <?php echo Form::label('freight', 'Freight:'); ?>

    <p><?php echo e($order->freight); ?></p>
</div>

<!-- Ship Name Field -->
<div class="form-group">
    <?php echo Form::label('ship_name', 'Ship Name:'); ?>

    <p><?php echo e($order->ship_name); ?></p>
</div>

<!-- Ship Address Field -->
<div class="form-group">
    <?php echo Form::label('ship_address', 'Ship Address:'); ?>

    <p><?php echo e($order->ship_address); ?></p>
</div>

<!-- Ship City Field -->
<div class="form-group">
    <?php echo Form::label('ship_city', 'Ship City:'); ?>

    <p><?php echo e($order->ship_city); ?></p>
</div>

<!-- Ship Region Field -->
<div class="form-group">
    <?php echo Form::label('ship_region', 'Ship Region:'); ?>

    <p><?php echo e($order->ship_region); ?></p>
</div>

<!-- Ship Postal Code Field -->
<div class="form-group">
    <?php echo Form::label('ship_postal_code', 'Ship Postal Code:'); ?>

    <p><?php echo e($order->ship_postal_code); ?></p>
</div>

<!-- Ship Country Field -->
<div class="form-group">
    <?php echo Form::label('ship_country', 'Ship Country:'); ?>

    <p><?php echo e($order->ship_country); ?></p>
</div>

<!-- Active Field -->
<div class="form-group">
    <?php echo Form::label('active', 'Active:'); ?>

    <p><?php echo e($order->active); ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($order->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($order->updated_at); ?></p>
</div>

<table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Producto</th>
      <th scope="col">Precio</th>
      <th scope="col">Cantidad</th>
      <th scope="col">Total</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $od): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($od->product_id); ?></th>
      <td><?php echo e(round($od->unit_price,2)); ?></td>
      <td><?php echo e($od->quantity); ?></td>
      <td><?php echo e($od->quantity * $od->unit_price); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table><?php /**PATH /home/vagrant/Code/miniMarket/resources/views/orders/show_fields.blade.php ENDPATH**/ ?>