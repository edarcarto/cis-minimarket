<!-- Category Name Field -->
<div class="form-group">
    <?php echo Form::label('category_name', 'Nombre Categoría:'); ?>

    <p><?php echo e($category->category_name); ?></p>
</div>

<!-- Category Id Field -->
<div class="form-group">
    <?php echo Form::label('category_id', 'Categoría Padre:'); ?>

    <p><?php echo e(($category->category) ? $category->category->category_name : ''); ?></p>
</div>

<!-- Parent Field -->
<div class="form-group">
    <?php echo Form::label('parent', 'Padre:'); ?>

    <p><?php echo e(($category->parent === 1) ? 'Si' : 'No'); ?></p>
</div>

<!-- Active Field -->
<div class="form-group">
    <?php echo Form::label('active', 'Activo:'); ?>

    <p><?php echo e(($category->active === 1) ? 'Si' : 'No'); ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Creado:'); ?>

    <p><?php echo e($category->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Actualizado:'); ?>

    <p><?php echo e($category->updated_at); ?></p>
</div>

<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/categories/show_fields.blade.php ENDPATH**/ ?>