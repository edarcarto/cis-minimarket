<!-- Address Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('address', 'Address:'); ?>

    <?php echo Form::text('address', null, ['class' => 'form-control']); ?>

</div>

<!-- phone Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('phone', 'phone:'); ?>

    <?php echo Form::text('phone', null, ['class' => 'form-control']); ?>

</div>

<!-- Active Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('status', 'Status:'); ?>

    <label class="checkbox-inline">
        <?php echo Form::hidden('status', 0); ?>

        <?php echo Form::checkbox('status', '1', null); ?>

    </label>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('shippers.index')); ?>" class="btn btn-default">Cancel</a>
</div>
<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/shippers/fields.blade.php ENDPATH**/ ?>