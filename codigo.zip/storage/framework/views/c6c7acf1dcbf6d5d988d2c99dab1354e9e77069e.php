<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://rawgit.com/enyo/dropzone/master/dist/dropzone.css" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Producto
        </h1>
    </section>
    <div class="content">
        <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="box box-primary">
            <div class="box-body">
                <div class="row">
                    <?php echo Form::open(['route' => 'products.store']); ?>


                        <?php echo $__env->make('products.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://rawgit.com/enyo/dropzone/master/dist/dropzone.js"></script>
<script type="text/javascript">
Dropzone.autoDiscover = false;
$(document).ready(function() {
    console.log( "ready!" );
    $("#upLoad").dropzone({
        addRemoveLinks: true,
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        url: "/api/upload/images/products",
        success: function(file,response){
            console.log("[response]",response);
            $("#contentImages").append(`<input type="hidden" id="${response.body.asset_id}" name="images_products[]" value="${response.body.public_id}|${response.body.asset_id}|${response.body.secure_url}" />`);
        },
        error: function(e){
            console.log("[error]",e);
        },
        removedfile: function(file) {
            console.log(`La success`,file);
            $.ajax({
                method: 'post',
                url: '/api/delete/images',
                data: JSON.parse(file.xhr.response),
                success: function(respuesta) {
                    console.log("respuesta",respuesta);
                    let cnt = JSON.parse(file.xhr.response);
                    $(`#${cnt.body.asset_id}`).remove();
                    file.previewElement.remove();
                },
                error: function(e) {
                    console.log("No se ha podido obtener la información",e);
                }
            });
        }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/miniMarket/resources/views/products/create.blade.php ENDPATH**/ ?>