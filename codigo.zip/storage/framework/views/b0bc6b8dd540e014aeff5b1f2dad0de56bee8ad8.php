<!-- Product Name Field -->
<div class="form-group">
    <?php echo Form::label('product_name', 'Nombre del Producto:'); ?>

    <p><?php echo e($product->product_name); ?></p>
</div>

<!-- Quantity Per Unit Field -->
<div class="form-group">
    <?php echo Form::label('quantity_per_unit', 'Cantidades por Unidad:'); ?>

    <p><?php echo e($product->quantity_per_unit); ?></p>
</div>

<!-- Unit Price Field -->
<div class="form-group">
    <?php echo Form::label('unit_price', 'Precio por Unidad:'); ?>

    <p><?php echo e($product->unit_price); ?></p>
</div>

<!-- Units In Stock Field -->
<div class="form-group">
    <?php echo Form::label('units_in_stock', 'Unidades en Stock:'); ?>

    <p><?php echo e($product->units_in_stock); ?></p>
</div>

<!-- Units On Order Field -->
<div class="form-group">
    <?php echo Form::label('units_on_order', 'Unidades en Pedido:'); ?>

    <p><?php echo e($product->units_on_order); ?></p>
</div>

<!-- Reorder Level Field -->
<div class="form-group">
    <?php echo Form::label('reorder_level', 'Punto de Pedido:'); ?>

    <p><?php echo e($product->reorder_level); ?></p>
</div>

<!-- Supplier Id Field -->
<div class="form-group">
    <?php echo Form::label('supplier_id', 'Proveedores:'); ?>

    <p><?php echo e($product->supplier->company_name); ?></p>
</div>

<!-- Category Id Field -->
<div class="form-group">
    <?php echo Form::label('category_id', 'Categorias:'); ?>

    <p><?php echo e($product->category->category_name); ?></p>
</div>

<!-- Trademark Id Field -->
<div class="form-group">
    <?php echo Form::label('trademark_id', 'Marca:'); ?>

    <p><?php echo e($product->trademark->trade_name); ?></p>
</div>

<!-- Active Field -->
<div class="form-group">
    <?php echo Form::label('active', 'Activo:'); ?>

    <p><?php echo e($product->active); ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($product->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($product->updated_at); ?></p>
</div>

<!-- Images -->
<div class="col-sm-12">
    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- <div class="card" style="width: 18rem;">
        <img src="<?php echo e($i->url); ?>" class="card-img-top" alt="Imagen">
    </div> -->
    <img src="<?php echo e($i->url); ?>" alt="Imagen" class="img-thumbnail col-sm-2">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/products/show_fields.blade.php ENDPATH**/ ?>