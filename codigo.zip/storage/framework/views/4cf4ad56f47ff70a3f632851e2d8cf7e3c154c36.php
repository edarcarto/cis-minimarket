<div class="table-responsive">
    <table class="table" id="products-table">
        <thead>
            <tr>
                <th>Nombre del Producto</th>
                <th>Cantidad por Unidad</th>
                <th>Precio por Unidad</th>
                <th>Unidades en Existencia</th>
                <th>Unidades en Pedido</th>
                <th>Punto de Pedido</th>
                <th>Proveedor</th>
                <th>Categoría</th>
                <th>Marca</th>
                <th>Descontinuado</th>
                <th>Activo</th>
                <th colspan="3">Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product->product_name); ?></td>
                <td><?php echo e($product->quantity_per_unit); ?></td>
                <td><?php echo e($product->unit_price); ?></td>
                <td><?php echo e($product->units_in_stock); ?></td>
                <td><?php echo e($product->units_on_order); ?></td>
                <td><?php echo e($product->reorder_level); ?></td>
                <td><?php echo e($product->supplier->company_name); ?></td>
                <td><?php echo e($product->category->category_name); ?></td>
                <td><?php echo e($product->trademark->trade_name); ?></td>
                <td><?php echo e(($product->descontinued) ? 'Si' : 'No'); ?></td>
                <td><?php echo e(($product->active) ? 'Si' : 'No'); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['products.destroy', $product->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('products.show', [$product->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('products.edit', [$product->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/products/table.blade.php ENDPATH**/ ?>