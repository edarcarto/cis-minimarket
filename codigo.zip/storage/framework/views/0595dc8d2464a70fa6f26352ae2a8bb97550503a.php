<!-- Address Field -->
<div class="form-group">
    <?php echo Form::label('address', 'Address:'); ?>

    <p><?php echo e($shipper->address); ?></p>
</div>

<!-- phone Field -->
<div class="form-group">
    <?php echo Form::label('phone', 'phone:'); ?>

    <p><?php echo e($shipper->phone); ?></p>
</div>

<!-- Status Field -->
<div class="form-group">
    <?php echo Form::label('status', 'Status:'); ?>

    <p><?php echo e($shipper->status); ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($shipper->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($shipper->updated_at); ?></p>
</div>

<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/shippers/show_fields.blade.php ENDPATH**/ ?>