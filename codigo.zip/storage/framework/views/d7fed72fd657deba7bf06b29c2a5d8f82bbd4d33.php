<!-- Company Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('company_name', 'Nombre de Compañia:'); ?>

    <?php echo Form::text('company_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Contact Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('contact_name', 'Nombre del Contacto:'); ?>

    <?php echo Form::text('contact_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Contact Title Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('contact_title', 'Puesto:'); ?>

    <?php echo Form::text('contact_title', null, ['class' => 'form-control']); ?>

</div>

<!-- Address Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('address', 'Dirección:'); ?>

    <?php echo Form::text('address', null, ['class' => 'form-control']); ?>

</div>

<!-- City Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('city', 'Ciudad:'); ?>

    <?php echo Form::text('city', null, ['class' => 'form-control']); ?>

</div>

<!-- Region Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('region', 'Región:'); ?>

    <?php echo Form::text('region', null, ['class' => 'form-control']); ?>

</div>

<!-- Postal Code Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('postal_code', 'Codigo Postal:'); ?>

    <?php echo Form::text('postal_code', null, ['class' => 'form-control']); ?>

</div>

<!-- Country Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('country', 'Pais:'); ?>

    <?php echo Form::text('country', null, ['class' => 'form-control']); ?>

</div>

<!-- Phone Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('phone', 'Teléfono:'); ?>

    <?php echo Form::tel('phone', null, ['class' => 'form-control']); ?>

</div>

<!-- Fax Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('fax', 'Fax:'); ?>

    <?php echo Form::tel('fax', null, ['class' => 'form-control']); ?>

</div>

<!-- Fax Homepage -->
<div class="form-group col-sm-6">
    <?php echo Form::label('homepage', 'Pagina Web:'); ?>

    <?php echo Form::url('homepage', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('suppliers.index')); ?>" class="btn btn-default">Cancelar</a>
</div>
<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/suppliers/fields.blade.php ENDPATH**/ ?>