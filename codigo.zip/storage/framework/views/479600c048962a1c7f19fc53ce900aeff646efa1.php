<!-- Category Name Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('category_name', 'Nombre Categoría:'); ?>

    <?php echo Form::text('category_name', null, ['class' => 'form-control']); ?>

</div>

<!-- Category Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('category_id', 'Categoría Padre:'); ?>

    <?php echo Form::select('category_id', $categoryItems, null, ['class' => 'form-control']); ?>

</div>

<!-- Parent Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('parent', 'Padre:'); ?>

    <label class="radio-inline">
        <?php echo Form::radio('parent', "1", null); ?> Yes
    </label>

    <label class="radio-inline">
        <?php echo Form::radio('parent', "0", null); ?> No
    </label>

</div>

<!-- Active Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('active', 'Activo:'); ?>

    <label class="checkbox-inline">
        <?php echo Form::hidden('active', 0); ?>

        <?php echo Form::checkbox('active', '1', null); ?>

    </label>
</div>


<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Guardar', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-default">Cancelar</a>
</div>
<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/categories/fields.blade.php ENDPATH**/ ?>