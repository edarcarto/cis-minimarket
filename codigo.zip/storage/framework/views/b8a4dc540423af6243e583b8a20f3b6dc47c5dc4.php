<div class="table-responsive">
    <table class="table" id="categories-table">
        <thead>
            <tr>
                <th>Nombre Categoría</th>
                <th>Categoría</th>
                <th>Padre</th>
                <th>Activo</th>
                <th colspan="3">Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($category->category_name); ?></td>
            <td><?php echo e(($category->category) ? $category->category->category_name : ''); ?></td>
            <td><?php echo e(($category->parent === 1) ? 'Si' : 'No'); ?></td>
            <td><?php echo e(($category->active === 1) ? 'Si' : 'No'); ?></td>
                <td>
                    <?php echo Form::open(['route' => ['categories.destroy', $category->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('categories.show', [$category->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                        <a href="<?php echo e(route('categories.edit', [$category->id])); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                        <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /home/vagrant/Code/miniMarket/resources/views/categories/table.blade.php ENDPATH**/ ?>