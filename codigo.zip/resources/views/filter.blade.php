@extends('layouts.web')
@section('js&css')
<!-- <link href="{{ secure_asset('css/cart/index.css') }}" media="all" rel="stylesheet" type="text/css" />
<script src="https://checkout.culqi.com/js/v3"></script>
<script src="{{ secure_asset('js/cart/index.js') }}"></script> -->
@endsection
@section('content')
@endsection
